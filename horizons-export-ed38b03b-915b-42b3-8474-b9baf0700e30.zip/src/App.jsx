
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import Dashboard from '@/components/Dashboard';

function App() {
  return (
    <>
      <Helmet>
        <title>Módulo Processual - PerfexCRM</title>
        <meta name="description" content="Sistema de consulta processual e acompanhamento de publicações do diário oficial para advogados" />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          <Dashboard />
        </motion.div>
        <Toaster />
      </div>
    </>
  );
}

export default App;
