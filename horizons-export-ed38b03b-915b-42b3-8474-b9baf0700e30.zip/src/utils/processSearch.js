
export const tribunals = [
  { code: 'TJSP', name: 'TJSP - Tribunal de Justiça de São Paulo', url: 'https://esaj.tjsp.jus.br', pattern: /\.8\.26\./ },
  { code: 'TJRJ', name: 'TJRJ - Tribunal de Justiça do Rio de Janeiro', url: 'https://www4.tjrj.jus.br', pattern: /\.8\.19\./ },
  { code: 'TJMG', name: 'TJMG - Tribunal de Justiça de Minas Gerais', url: 'https://pje.tjmg.jus.br', pattern: /\.8\.13\./ },
  { code: 'TJRS', name: 'TJRS - Tribunal de Justiça do Rio Grande do Sul', url: 'https://www.tjrs.jus.br', pattern: /\.8\.21\./ },
  { code: 'TJPR', name: 'TJPR - Tribunal de Justiça do Paraná', url: 'https://portal.tjpr.jus.br', pattern: /\.8\.16\./ },
  { code: 'TJSC', name: 'TJSC - Tribunal de Justiça de Santa Catarina', url: 'https://esaj.tjsc.jus.br', pattern: /\.8\.24\./ },
  { code: 'TJBA', name: 'TJBA - Tribunal de Justiça da Bahia', url: 'https://esaj.tjba.jus.br', pattern: /\.8\.05\./ },
  { code: 'TJGO', name: 'TJGO - Tribunal de Justiça de Goiás', url: 'https://projudi.tjgo.jus.br', pattern: /\.8\.09\./ },
  { code: 'TJDF', name: 'TJDF - Tribunal de Justiça do Distrito Federal', url: 'https://pje.tjdft.jus.br', pattern: /\.8\.07\./ },
  { code: 'TJPE', name: 'TJPE - Tribunal de Justiça de Pernambuco', url: 'https://www.tjpe.jus.br', pattern: /\.8\.17\./ },
  { code: 'TRT18', name: 'TRT18 - Tribunal Regional do Trabalho 18ª Região (GO)', url: 'https://pje.trt18.jus.br', pattern: /\.5\.18\./ },
  { code: 'STJ', name: 'STJ - Superior Tribunal de Justiça', url: 'https://www.stj.jus.br', pattern: /\.30\./ },
  { code: 'STF', name: 'STF - Supremo Tribunal Federal', url: 'https://www.stf.jus.br', pattern: /\.01\./ },
  { code: 'TST', name: 'TST - Tribunal Superior do Trabalho', url: 'https://www.tst.jus.br', pattern: /\.5\.90\./ },
  { code: 'TRT1', name: 'TRT1 - Tribunal Regional do Trabalho 1ª Região (RJ)', url: 'https://www.trt1.jus.br', pattern: /\.5\.01\./ },
  { code: 'TRT2', name: 'TRT2 - Tribunal Regional do Trabalho 2ª Região (SP)', url: 'https://www.trt2.jus.br', pattern: /\.5\.02\./ },
  { code: 'TRT3', name: 'TRT3 - Tribunal Regional do Trabalho 3ª Região (MG)', url: 'https://www.trt3.jus.br', pattern: /\.5\.03\./ },
  { code: 'TRT4', name: 'TRT4 - Tribunal Regional do Trabalho 4ª Região (RS)', url: 'https://www.trt4.jus.br', pattern: /\.5\.04\./ },
  { code: 'TRF1', name: 'TRF1 - Tribunal Regional Federal 1ª Região', url: 'https://www.trf1.jus.br', pattern: /\.4\.01\./ },
  { code: 'TRF2', name: 'TRF2 - Tribunal Regional Federal 2ª Região', url: 'https://www.trf2.jus.br', pattern: /\.4\.02\./ },
  { code: 'TRF3', name: 'TRF3 - Tribunal Regional Federal 3ª Região', url: 'https://www.trf3.jus.br', pattern: /\.4\.03\./ },
  { code: 'TRF4', name: 'TRF4 - Tribunal Regional Federal 4ª Região', url: 'https://www.trf4.jus.br', pattern: /\.4\.04\./ }
];

const mockProcessDatabase = {
  "0024804-11.2019.8.09.0076": {
    tribunalCode: 'TJGO',
    subject: 'Estelionato',
    class: 'Procedimento Comum - Ação Penal',
    type: 'Criminal',
    parties: {
      plaintiff: 'Gilberto Dorival Romano',
      defendant: 'Sebastião Egídio de Oliveira; Domingos Pereira Souto Neto',
      plaintiffCpf: '720.484.418-15',
      defendantCnpj: '076.945.121-72; 009.143.171-99',
    },
    judge: 'Juiz Titular da Comarca',
    vara: 'Vara Criminal de Iporá - II',
    comarca: 'Iporá',
    value: 'Sem valor econômico',
    distribuition: '25/02/2019',
    lawyers: [
      { name: 'Tatiane Miriele de Moura Cunha', oab: 'OAB/GO 46045', party: 'Polo Ativo' },
      { name: 'Alessandra Alves de Oliveira', oab: 'OAB/GO 37349', party: 'Polo Passivo' },
      { name: 'Renato Júnio Rua', oab: 'OAB/GO 46459', party: 'Polo Passivo' },
    ],
    movements: [
      { date: '20/05/2024', time: '11:20', description: 'Conclusos para decisão', type: 'Conclusão', responsible: 'Cartório' },
      { date: '15/05/2024', time: '15:45', description: 'Juntada de alegações finais pela defesa', type: 'Petição', responsible: 'Advogado do Réu' },
      { date: '01/05/2024', time: '17:00', description: 'Juntada de alegações finais pela acusação', type: 'Petição', responsible: 'Advogado do Autor' },
    ],
    documents: [
      { name: 'Denúncia MP', date: '25/02/2019', type: 'PDF', url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
      { name: 'Decisão de Recebimento', date: '01/03/2019', type: 'PDF', url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
      { name: 'Alegações Finais Defesa', date: '15/05/2024', type: 'PDF', url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
    ]
  },
  "0000081-88.2025.5.18.0181": {
    tribunalCode: 'TRT18',
    subject: 'Reconhecimento de Vínculo Empregatício',
    class: 'Ação Trabalhista - Rito Ordinário',
    type: 'Trabalhista',
    parties: {
      plaintiff: 'Maria Joaquina de Amaral Pereira',
      defendant: 'Tecnologia Avançada Ltda.',
      plaintiffCpf: '111.222.333-44',
      defendantCnpj: '99.888.777/0001-66',
    },
    judge: 'Dr. Fabricio Alves da Cunha',
    vara: '1ª Vara do Trabalho de Rio Verde',
    comarca: 'Rio Verde',
    value: 'R$ 150.000,00',
    distribuition: '01/01/2025',
    lawyers: [
      { name: 'Dr. Advogado do Reclamante', oab: 'OAB/GO 11223', party: 'Polo Ativo' },
      { name: 'Dr. Advogado da Reclamada', oab: 'OAB/GO 48353', party: 'Polo Passivo' }
    ],
    movements: [
      { date: '10/01/2025', time: '14:00', description: 'Audiência de Instrução e Julgamento designada', type: 'Audiência', responsible: 'Secretaria da Vara' },
    ],
    documents: [
      { name: 'Petição Inicial', date: '01/01/2025', type: 'PDF', url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' }
    ]
  }
};


const detectTribunalFromNumber = (processNumber) => {
  const cleanNumber = processNumber.replace(/[^\d-.]/g, '');
  for (const tribunal of tribunals) {
    if (tribunal.pattern && tribunal.pattern.test(cleanNumber)) {
      return tribunal;
    }
  }
  return null;
};

const generateGenericMockData = (processNumber, tribunal) => {
  return {
    number: processNumber,
    court: tribunal.name,
    courtCode: tribunal.code,
    courtUrl: tribunal.url,
    status: 'Ativo',
    lastMovement: 'Juntada de petição inicial com documentos',
    lastUpdate: new Date().toLocaleDateString('pt-BR'),
    parties: {
      plaintiff: 'Requerente Genérico Exemplo',
      defendant: 'Requerido Genérico Exemplo Ltda',
      plaintiffCpf: '123.456.789-00',
      defendantCnpj: '12.345.678/0001-90'
    },
    lawyers: [{ name: 'Dr. Advogado Padrão', oab: `OAB/${tribunal.code.replace('TJ', '') || 'DF'} 123456`, party: 'Polo Ativo' }],
    value: 'R$ 50.000,00',
    subject: 'Ação Genérica de Exemplo',
    class: 'Procedimento Padrão',
    judge: 'Dr. Juiz Padrão',
    vara: '1ª Vara Genérica',
    comarca: 'Comarca Padrão',
    distribuition: '01/01/2024',
    movements: [{ date: '02/01/2024', time: '10:00', description: 'Distribuição por sorteio', type: 'Distribuição', responsible: 'Sistema' }],
    documents: [{ name: 'Petição Inicial', date: '01/01/2024', type: 'PDF', url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' }]
  };
};

export const searchProcessInTribunals = async (processNumber, setProgress) => {
  const cleanProcessNumber = processNumber.replace(/[^\d.-]/g, '');
  const specificData = mockProcessDatabase[cleanProcessNumber];
  
  const detectedTribunal = specificData 
    ? tribunals.find(t => t.code === specificData.tribunalCode)
    : detectTribunalFromNumber(cleanProcessNumber);

  if (detectedTribunal) {
    setProgress([{ tribunal: detectedTribunal.name, status: 'searching' }]);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setProgress([{ tribunal: detectedTribunal.name, status: 'found' }]);

    if (specificData) {
      return {
        number: cleanProcessNumber,
        court: detectedTribunal.name,
        courtCode: detectedTribunal.code,
        courtUrl: detectedTribunal.url,
        status: 'Ativo',
        lastMovement: specificData.movements[0].description,
        lastUpdate: new Date().toLocaleDateString('pt-BR'),
        ...specificData
      };
    } else {
      return generateGenericMockData(cleanProcessNumber, detectedTribunal);
    }
  }

  // Fallback to sequential search if no pattern matches
  const searchOrder = ['TJSP', 'TJRJ', 'TJMG', 'TJGO', 'TJRS', 'TJPR', 'STJ', 'STF', 'TST'];
  for (const tribunalCode of searchOrder) {
    const tribunal = tribunals.find(t => t.code === tribunalCode);
    setProgress(prev => [...prev.filter(p => p.tribunal !== tribunal.name), { tribunal: tribunal.name, status: 'searching' }]);
    await new Promise(resolve => setTimeout(resolve, 600));
    setProgress(prev => prev.map(p => p.tribunal === tribunal.name ? { ...p, status: 'not_found' } : p));
  }

  throw new Error('Processo não encontrado em nenhum tribunal consultado.');
};
