
export const tribunals = [
  { code: 'TJSP', name: 'TJSP - Tribunal de Justiça de São Paulo', url: 'https://esaj.tjsp.jus.br' },
  { code: 'TJRJ', name: 'TJRJ - Tribunal de Justiça do Rio de Janeiro', url: 'https://www4.tjrj.jus.br' },
  { code: 'TJMG', name: 'TJMG - Tribunal de Justiça de Minas Gerais', url: 'https://pje.tjmg.jus.br' },
  { code: 'TJRS', name: 'TJRS - Tribunal de Justiça do Rio Grande do Sul', url: 'https://www.tjrs.jus.br' },
  { code: 'TJPR', name: 'TJPR - Tribunal de Justiça do Paraná', url: 'https://portal.tjpr.jus.br' },
  { code: 'TJSC', name: 'TJSC - Tribunal de Justiça de Santa Catarina', url: 'https://esaj.tjsc.jus.br' },
  { code: 'TJBA', name: 'TJBA - Tribunal de Justiça da Bahia', url: 'https://esaj.tjba.jus.br' },
  { code: 'TJGO', name: 'TJGO - Tribunal de Justiça de Goiás', url: 'https://projudi.tjgo.jus.br' },
  { code: 'TJDF', name: 'TJDF - Tribunal de Justiça do Distrito Federal', url: 'https://pje.tjdft.jus.br' },
  { code: 'TJPE', name: 'TJPE - Tribunal de Justiça de Pernambuco', url: 'https://www.tjpe.jus.br' },
  { code: 'STJ', name: 'STJ - Superior Tribunal de Justiça', url: 'https://www.stj.jus.br' },
  { code: 'STF', name: 'STF - Supremo Tribunal Federal', url: 'https://www.stf.jus.br' },
  { code: 'TST', name: 'TST - Tribunal Superior do Trabalho', url: 'https://www.tst.jus.br' },
  { code: 'TRT1', name: 'TRT1 - Tribunal Regional do Trabalho 1ª Região (RJ)', url: 'https://www.trt1.jus.br' },
  { code: 'TRT2', name: 'TRT2 - Tribunal Regional do Trabalho 2ª Região (SP)', url: 'https://www.trt2.jus.br' },
  { code: 'TRT3', name: 'TRT3 - Tribunal Regional do Trabalho 3ª Região (MG)', url: 'https://www.trt3.jus.br' },
  { code: 'TRT4', name: 'TRT4 - Tribunal Regional do Trabalho 4ª Região (RS)', url: 'https://www.trt4.jus.br' },
  { code: 'TRF1', name: 'TRF1 - Tribunal Regional Federal 1ª Região', url: 'https://www.trf1.jus.br' },
  { code: 'TRF2', name: 'TRF2 - Tribunal Regional Federal 2ª Região', url: 'https://www.trf2.jus.br' },
  { code: 'TRF3', name: 'TRF3 - Tribunal Regional Federal 3ª Região', url: 'https://www.trf3.jus.br' },
  { code: 'TRF4', name: 'TRF4 - Tribunal Regional Federal 4ª Região', url: 'https://www.trf4.jus.br' }
];

export const processTypes = [
  { value: 'civil', label: 'Cível' },
  { value: 'criminal', label: 'Criminal' },
  { value: 'trabalhista', label: 'Trabalhista' },
  { value: 'tributario', label: 'Tributário' },
  { value: 'familia', label: 'Família' },
  { value: 'empresarial', label: 'Empresarial' },
  { value: 'consumidor', label: 'Consumidor' },
  { value: 'previdenciario', label: 'Previdenciário' }
];
