
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Search, Filter, Eye, Trash2, Calendar, Building, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import ProcessDetailModal from '@/components/ProcessDetailModal';

const ProcessList = ({ processes, setProcesses }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [selectedProcess, setSelectedProcess] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const filteredProcesses = processes.filter(process => {
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch = process.number.toLowerCase().includes(searchLower) ||
                         (process.lawyers && process.lawyers.some(l => l.name.toLowerCase().includes(searchLower))) ||
                         process.court.toLowerCase().includes(searchLower) ||
                         process.subject.toLowerCase().includes(searchLower);
    
    const matchesFilter = filterStatus === 'all' || process.status.toLowerCase() === filterStatus.toLowerCase();
    
    return matchesSearch && matchesFilter;
  });

  const handleDeleteProcess = (processId) => {
    const updatedProcesses = processes.filter(p => p.id !== processId);
    setProcesses(updatedProcesses);
    localStorage.setItem('processual_processes', JSON.stringify(updatedProcesses));
    
    toast({
      title: "Processo Removido",
      description: "O processo foi removido do monitoramento.",
    });
  };

  const handleViewDetails = (process) => {
    setSelectedProcess(process);
    setIsModalOpen(true);
  };
  
  const updateProcessData = (updatedProcess) => {
    const updatedProcesses = processes.map(p => p.id === updatedProcess.id ? updatedProcess : p);
    setProcesses(updatedProcesses);
    localStorage.setItem('processual_processes', JSON.stringify(updatedProcesses));
    setSelectedProcess(updatedProcess); 
  };


  return (
    <>
      <ProcessDetailModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        process={selectedProcess}
        onUpdateProcess={updateProcessData}
      />
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold text-white">Processos Monitorados</h2>
          <div className="text-sm text-gray-300">
            {filteredProcesses.length} de {processes.length} processos
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-6"
        >
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  placeholder="Buscar por número, advogado, assunto ou tribunal..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder-gray-400"
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Filter className="w-5 h-5 text-gray-400" />
                <Select
                  value={filterStatus}
                  onValueChange={setFilterStatus}
                  className="bg-slate-800 border-slate-600"
                >
                  <option value="all">Todos os Status</option>
                  <option value="Ativo">Ativo</option>
                  <option value="Arquivado">Arquivado</option>
                  <option value="Suspenso">Suspenso</option>
                </Select>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="space-y-4">
          {filteredProcesses.length > 0 ? (
            filteredProcesses.map((process, index) => (
              <motion.div
                key={process.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-6 hover:bg-white/15 transition-all duration-300"
              >
                <div className="flex flex-col md:flex-row items-start justify-between">
                  <div className="flex-1 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                          <FileText className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-white">{process.number}</h3>
                          <p className="text-gray-300">{process.subject || 'Assunto não informado'}</p>
                        </div>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                          process.status === 'Ativo' ? 'bg-green-500/20 text-green-300'
                          : process.status === 'Arquivado' ? 'bg-gray-500/20 text-gray-300'
                          : 'bg-yellow-500/20 text-yellow-300'
                      }`}>
                        {process.status}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div className="flex items-center space-x-2"><Building className="w-4 h-4 text-blue-400" /><p>{process.court}</p></div>
                      <div className="flex items-center space-x-2"><Calendar className="w-4 h-4 text-blue-400" /><p>Últ. Att: {new Date(process.lastUpdate).toLocaleDateString('pt-BR')}</p></div>
                      <div className="flex items-center space-x-2"><Info className="w-4 h-4 text-blue-400" /><p>{process.lawyers ? process.lawyers[0].name : 'N/A'}</p></div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2 mt-4 md:mt-0 md:ml-6">
                    <Button variant="ghost" size="sm" onClick={() => handleViewDetails(process)} className="text-blue-300 hover:text-white hover:bg-blue-500/20"><Eye className="w-4 h-4 mr-2" /> Detalhes</Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDeleteProcess(process.id)} className="text-red-300 hover:text-white hover:bg-red-500/20"><Trash2 className="w-4 h-4" /></Button>
                  </div>
                </div>
              </motion.div>
            ))
          ) : (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-12 text-center">
              <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">{searchTerm || filterStatus !== 'all' ? 'Nenhum processo encontrado' : 'Nenhum processo monitorado'}</h3>
              <p className="text-gray-400">{searchTerm || filterStatus !== 'all' ? 'Tente ajustar os filtros de busca' : 'Comece adicionando processos para monitoramento'}</p>
            </motion.div>
          )}
        </div>
      </div>
    </>
  );
};

export default ProcessList;
