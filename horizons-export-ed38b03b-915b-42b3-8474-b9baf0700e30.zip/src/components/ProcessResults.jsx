
import React from 'react';
import { motion } from 'framer-motion';
import { FileText, User, Users, Calendar, Plus, Download, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const ProcessResults = ({ searchResults, onAddToMonitoring, onExportToPerfex }) => {
  const handleOpenPdf = (url) => {
    if (url) {
      window.open(url, '_blank');
    } else {
      toast({
        title: "Link não disponível",
        description: "Este documento não possui um link para visualização.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-8 mt-8"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-white">Resultado da Consulta</h3>
        <div className="flex space-x-3">
          <Button
            onClick={onExportToPerfex}
            variant="outline"
            size="sm"
            className="border-green-500 text-green-400 hover:bg-green-500/10"
          >
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
          <Button
            onClick={onAddToMonitoring}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Monitorar
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        <div className="xl:col-span-2 space-y-6">
          <div className="bg-white/5 rounded-lg p-6 border border-white/10">
            <h4 className="text-lg font-medium text-white mb-4 flex items-center">
              <FileText className="w-5 h-5 mr-2 text-blue-400" />
              Informações do Processo
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div><p className="text-xs text-gray-400">Número</p><p className="text-white font-medium">{searchResults.number}</p></div>
                <div><p className="text-xs text-gray-400">Tribunal</p><p className="text-white font-medium">{searchResults.court}</p></div>
                <div><p className="text-xs text-gray-400">Classe</p><p className="text-white font-medium">{searchResults.class}</p></div>
                <div><p className="text-xs text-gray-400">Assunto</p><p className="text-white font-medium">{searchResults.subject}</p></div>
              </div>
              
              <div className="space-y-3">
                <div><p className="text-xs text-gray-400">Valor da Causa</p><p className="text-white font-medium">{searchResults.value}</p></div>
                <div><p className="text-xs text-gray-400">Juiz</p><p className="text-white font-medium">{searchResults.judge}</p></div>
                <div><p className="text-xs text-gray-400">Vara</p><p className="text-white font-medium">{searchResults.vara}</p></div>
                <div><p className="text-xs text-gray-400">Distribuição</p><p className="text-white font-medium">{searchResults.distribuition}</p></div>
              </div>
            </div>
          </div>
          
          <div className="bg-white/5 rounded-lg p-6 border border-white/10">
            <h4 className="text-lg font-medium text-white mb-4 flex items-center">
              <Users className="w-5 h-5 mr-2 text-blue-400" />
              Partes e Advogados
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <p className="text-sm text-green-400 font-medium mb-2">Polo Ativo</p>
                <p className="text-white font-medium">{searchResults.parties.plaintiff}</p>
                <p className="text-xs text-gray-400">{searchResults.parties.plaintiffCpf}</p>
              </div>
              
              <div>
                <p className="text-sm text-red-400 font-medium mb-2">Polo Passivo</p>
                <p className="text-white font-medium">{searchResults.parties.defendant}</p>
                <p className="text-xs text-gray-400">{searchResults.parties.defendantCnpj}</p>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-white/10">
              <p className="text-sm text-blue-400 font-medium mb-2">Advogados</p>
              <div className="space-y-2">
                {searchResults.lawyers && searchResults.lawyers.map((lawyer, index) => (
                  <div key={index}><p className="text-white font-medium">{lawyer.name} <span className="text-xs text-gray-400">({lawyer.oab}) - {lawyer.party}</span></p></div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        <div className="space-y-6">
          <div className="bg-white/5 rounded-lg p-6 border border-white/10">
            <h4 className="text-lg font-medium text-white mb-4 flex items-center">
              <Calendar className="w-5 h-5 mr-2 text-blue-400" />
              Movimentações
            </h4>
            
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {searchResults.movements.map((movement, index) => (
                <div key={index} className="border-l-2 border-blue-400 pl-4 pb-4 last:pb-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-gray-300">{movement.date} - {movement.time}</span>
                    <span className="px-2 py-1 bg-blue-500/20 text-blue-300 rounded text-xs">{movement.type}</span>
                  </div>
                  <p className="text-sm text-white mb-1">{movement.description}</p>
                  <p className="text-xs text-gray-400">{movement.responsible}</p>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-white/5 rounded-lg p-6 border border-white/10">
            <h4 className="text-lg font-medium text-white mb-4">Documentos</h4>
            <div className="space-y-3">
              {searchResults.documents.map((doc, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-white/5 rounded border border-white/10">
                  <div>
                    <p className="text-sm text-white font-medium">{doc.name}</p>
                    <p className="text-xs text-gray-400">{doc.date}</p>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => handleOpenPdf(doc.url)}>
                    <ExternalLink className="w-4 h-4 text-blue-300" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default ProcessResults;
