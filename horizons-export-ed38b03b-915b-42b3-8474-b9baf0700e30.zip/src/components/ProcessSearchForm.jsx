import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Plus, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { tribunals, processTypes } from '@/utils/processData';
import ProcessResults from '@/components/ProcessResults';

const ProcessSearchForm = ({ onAddProcess }) => {
  const [searchData, setSearchData] = useState({
    number: '',
    court: '',
    type: 'civil',
    lawyer: '',
    client: '',
    oab: ''
  });
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState(null);

  const handleSearch = async () => {
    if (!searchData.number.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, informe o número do processo.",
        variant: "destructive"
      });
      return;
    }

    setIsSearching(true);
    
    setTimeout(() => {
      const selectedTribunal = tribunals.find(t => t.code === searchData.court) || 
                              tribunals.find(t => t.code === 'TJSP');
      
      const mockResult = {
        number: searchData.number,
        court: selectedTribunal.name,
        courtCode: selectedTribunal.code,
        courtUrl: selectedTribunal.url,
        status: 'Ativo',
        lastMovement: 'Juntada de petição inicial',
        lastUpdate: new Date().toLocaleDateString('pt-BR'),
        parties: {
          plaintiff: searchData.client || 'João Silva Santos',
          defendant: 'Empresa ABC Comércio Ltda',
          plaintiffCpf: '123.456.789-00',
          defendantCnpj: '12.345.678/0001-90'
        },
        lawyer: searchData.lawyer || 'Dr. Maria Santos',
        oab: searchData.oab || `OAB/${selectedTribunal.code.replace('TJ', '') || 'SP'} 123456`,
        value: 'R$ 75.500,00',
        subject: searchData.type === 'criminal' ? 'Ação Penal - Furto Qualificado' : 'Ação de Cobrança - Prestação de Serviços',
        class: searchData.type === 'criminal' ? 'Ação Penal de Competência do Júri' : 'Procedimento Comum Cível',
        judge: 'Dr. Carlos Eduardo Silva',
        vara: searchData.type === 'criminal' ? '1ª Vara Criminal' : '1ª Vara Cível',
        comarca: selectedTribunal.code === 'TJGO' ? 'Goiânia' : 'São Paulo',
        distribuition: '15/10/2024',
        movements: [
          {
            date: '20/12/2024',
            time: '14:30',
            description: searchData.type === 'criminal' ? 
              'Recebimento da denúncia. Cite-se o réu para resposta à acusação.' :
              'Juntada de petição inicial com documentos',
            type: searchData.type === 'criminal' ? 'Despacho' : 'Petição',
            responsible: searchData.type === 'criminal' ? 'Juiz' : 'Advogado do Autor'
          },
          {
            date: '18/12/2024',
            time: '10:15',
            description: searchData.type === 'criminal' ? 
              'Oferecimento de denúncia pelo Ministério Público' :
              'Despacho: Cite-se o requerido para contestar no prazo legal',
            type: searchData.type === 'criminal' ? 'Petição' : 'Despacho',
            responsible: searchData.type === 'criminal' ? 'Ministério Público' : 'Juiz'
          }
        ],
        documents: [
          { name: searchData.type === 'criminal' ? 'Denúncia' : 'Petição Inicial', date: '15/12/2024', type: 'PDF' },
          { name: 'Procuração', date: '15/12/2024', type: 'PDF' },
          { name: searchData.type === 'criminal' ? 'Inquérito Policial' : 'Documentos Pessoais', date: '15/12/2024', type: 'PDF' }
        ]
      };
      
      setSearchResults(mockResult);
      setIsSearching(false);
      
      toast({
        title: "Busca Concluída!",
        description: `Processo encontrado no ${selectedTribunal.code}.`,
      });
    }, 2000);
  };

  const handleAddToMonitoring = () => {
    if (searchResults) {
      onAddProcess(searchResults);
      setSearchResults(null);
      setSearchData({
        number: '',
        court: '',
        type: 'civil',
        lawyer: '',
        client: '',
        oab: ''
      });
      
      toast({
        title: "Processo Adicionado!",
        description: `Processo ${searchResults.number} foi adicionado ao monitoramento.`,
      });
    }
  };

  const handleExportToPerfex = () => {
    if (!searchResults) return;

    const perfexData = {
      module: 'processual',
      version: '1.0',
      export_date: new Date().toISOString(),
      process: {
        number: searchResults.number,
        court: searchResults.court,
        court_code: searchResults.courtCode,
        status: searchResults.status,
        subject: searchResults.subject,
        class: searchResults.class,
        value: searchResults.value,
        judge: searchResults.judge,
        vara: searchResults.vara,
        comarca: searchResults.comarca,
        distribution_date: searchResults.distribuition,
        last_update: searchResults.lastUpdate,
        parties: {
          plaintiff: {
            name: searchResults.parties.plaintiff,
            document: searchResults.parties.plaintiffCpf,
            type: 'person'
          },
          defendant: {
            name: searchResults.parties.defendant,
            document: searchResults.parties.defendantCnpj,
            type: 'company'
          }
        },
        lawyer: {
          name: searchResults.lawyer,
          oab: searchResults.oab
        },
        movements: searchResults.movements,
        documents: searchResults.documents,
        monitoring: {
          active: true,
          created_at: new Date().toISOString(),
          notifications: true
        }
      }
    };

    const blob = new Blob([JSON.stringify(perfexData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `processo_${searchResults.number.replace(/[^0-9]/g, '')}_perfexcrm.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Arquivo Exportado!",
      description: "Dados do processo exportados para importação no PerfexCRM.",
    });
  };

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-8"
      >
        <div className="flex items-center space-x-3 mb-6">
          <Settings className="w-6 h-6 text-blue-400" />
          <h3 className="text-xl font-semibold text-white">Busca Avançada</h3>
          <span className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm">
            Opcional
          </span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Número do Processo *
            </label>
            <Input
              placeholder="Ex: 1234567-89.2024.8.26.0001"
              value={searchData.number}
              onChange={(e) => setSearchData({...searchData, number: e.target.value})}
              className="bg-white/10 border-white/20 text-white placeholder-gray-400"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Tribunal Específico
            </label>
            <Select
              value={searchData.court}
              onValueChange={(value) => setSearchData({...searchData, court: value})}
              placeholder="Selecione o tribunal"
              className="bg-white/10 border-white/20 text-white"
            >
              {tribunals.map((tribunal) => (
                <option key={tribunal.code} value={tribunal.code}>
                  {tribunal.name}
                </option>
              ))}
            </Select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Tipo de Processo
            </label>
            <Select
              value={searchData.type}
              onValueChange={(value) => setSearchData({...searchData, type: value})}
              className="bg-white/10 border-white/20 text-white"
            >
              {processTypes.map((type) => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </Select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Advogado Responsável
            </label>
            <Input
              placeholder="Nome do advogado"
              value={searchData.lawyer}
              onChange={(e) => setSearchData({...searchData, lawyer: e.target.value})}
              className="bg-white/10 border-white/20 text-white placeholder-gray-400"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              OAB
            </label>
            <Input
              placeholder="Ex: OAB/SP 123456"
              value={searchData.oab}
              onChange={(e) => setSearchData({...searchData, oab: e.target.value})}
              className="bg-white/10 border-white/20 text-white placeholder-gray-400"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Cliente
            </label>
            <Input
              placeholder="Nome do cliente"
              value={searchData.client}
              onChange={(e) => setSearchData({...searchData, client: e.target.value})}
              className="bg-white/10 border-white/20 text-white placeholder-gray-400"
            />
          </div>
        </div>
        
        <div className="mt-8">
          <Button
            onClick={handleSearch}
            disabled={isSearching}
            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
          >
            {isSearching ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Consultando...
              </>
            ) : (
              <>
                <Search className="w-4 h-4 mr-2" />
                Busca Avançada
              </>
            )}
          </Button>
        </div>
      </motion.div>

      {searchResults && (
        <ProcessResults 
          searchResults={searchResults}
          onAddToMonitoring={handleAddToMonitoring}
          onExportToPerfex={handleExportToPerfex}
        />
      )}
    </div>
  );
};

export default ProcessSearchForm;