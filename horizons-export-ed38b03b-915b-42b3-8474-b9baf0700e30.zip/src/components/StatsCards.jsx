
import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Bell, TrendingUp, Clock } from 'lucide-react';

const StatsCards = ({ processes, publications }) => {
  const activeProcesses = processes.filter(p => p.status === 'Ativo').length;
  const unreadPublications = publications.filter(p => !p.read).length;
  const totalProcesses = processes.length;
  const totalPublications = publications.length;

  const stats = [
    {
      title: 'Processos Ativos',
      value: activeProcesses,
      total: totalProcesses,
      icon: FileText,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-500/20',
      textColor: 'text-blue-300'
    },
    {
      title: 'Publicações Não Lidas',
      value: unreadPublications,
      total: totalPublications,
      icon: Bell,
      color: 'from-orange-500 to-red-600',
      bgColor: 'bg-orange-500/20',
      textColor: 'text-orange-300'
    },
    {
      title: 'Total de Processos',
      value: totalProcesses,
      icon: TrendingUp,
      color: 'from-green-500 to-emerald-600',
      bgColor: 'bg-green-500/20',
      textColor: 'text-green-300'
    },
    {
      title: 'Atualizações Hoje',
      value: 0, // Placeholder - seria calculado baseado em atualizações do dia
      icon: Clock,
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-500/20',
      textColor: 'text-purple-300'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-6 hover:bg-white/15 transition-all duration-300"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 bg-gradient-to-r ${stat.color} rounded-lg flex items-center justify-center`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              
              {stat.total !== undefined && stat.value > 0 && (
                <div className={`px-2 py-1 ${stat.bgColor} rounded-full`}>
                  <span className={`text-xs font-medium ${stat.textColor}`}>
                    {stat.value}/{stat.total}
                  </span>
                </div>
              )}
            </div>
            
            <div>
              <h3 className="text-2xl font-bold text-white mb-1">{stat.value}</h3>
              <p className="text-gray-300 text-sm">{stat.title}</p>
            </div>
            
            {stat.total !== undefined && (
              <div className="mt-4">
                <div className="w-full bg-white/10 rounded-full h-2">
                  <div
                    className={`bg-gradient-to-r ${stat.color} h-2 rounded-full transition-all duration-500`}
                    style={{
                      width: stat.total > 0 ? `${(stat.value / stat.total) * 100}%` : '0%'
                    }}
                  ></div>
                </div>
              </div>
            )}
          </motion.div>
        );
      })}
    </div>
  );
};

export default StatsCards;
