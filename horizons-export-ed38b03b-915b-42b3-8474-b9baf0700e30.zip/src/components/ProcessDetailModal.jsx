
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/use-toast";
import { Calendar, FileText, Bug as Note, Users, Link, Plus, Trash2, ExternalLink, Share2, Clock } from 'lucide-react';

const ProcessDetailModal = ({ isOpen, onClose, process, onUpdateProcess }) => {
  const [notes, setNotes] = useState(process?.notes || '');
  const [commitments, setCommitments] = useState(process?.commitments || []);
  const [newCommitment, setNewCommitment] = useState({ date: '', description: '' });

  if (!process) return null;

  const handleSaveNotes = () => {
    onUpdateProcess({ ...process, notes });
    toast({ title: "Anotações Salvas!", description: "Suas anotações foram salvas com sucesso." });
  };
  
  const handleAddCommitment = () => {
    if (newCommitment.date && newCommitment.description) {
      const updatedCommitments = [...commitments, { id: Date.now(), ...newCommitment }];
      setCommitments(updatedCommitments);
      onUpdateProcess({ ...process, commitments: updatedCommitments });
      setNewCommitment({ date: '', description: '' });
      toast({ title: "Compromisso Adicionado!", description: "Novo prazo/audiência salvo." });
    } else {
      toast({ title: "Erro", description: "Preencha a data e a descrição do compromisso.", variant: "destructive" });
    }
  };

  const handleDeleteCommitment = (id) => {
    const updatedCommitments = commitments.filter(c => c.id !== id);
    setCommitments(updatedCommitments);
    onUpdateProcess({ ...process, commitments: updatedCommitments });
  };
  
  const handleOpenPdf = (url) => {
    if (url) window.open(url, '_blank');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl bg-slate-900/80 backdrop-blur-lg border-slate-700 text-white">
        <DialogHeader>
          <DialogTitle className="text-2xl">{process.number}</DialogTitle>
          <DialogDescription>{process.subject}</DialogDescription>
        </DialogHeader>
        <Tabs defaultValue="movements" className="w-full mt-4">
          <TabsList className="grid w-full grid-cols-5 bg-slate-800">
            <TabsTrigger value="movements"><Calendar className="w-4 h-4 mr-2" />Movimentações</TabsTrigger>
            <TabsTrigger value="documents"><FileText className="w-4 h-4 mr-2" />Documentos</TabsTrigger>
            <TabsTrigger value="notes"><Note className="w-4 h-4 mr-2" />Anotações</TabsTrigger>
            <TabsTrigger value="commitments"><Clock className="w-4 h-4 mr-2" />Prazos</TabsTrigger>
            <TabsTrigger value="actions"><Link className="w-4 h-4 mr-2" />Ações</TabsTrigger>
          </TabsList>
          
          <TabsContent value="movements" className="mt-4 max-h-[60vh] overflow-y-auto">
            {process.movements.map((mov, index) => (
              <div key={index} className="border-l-2 border-blue-400 pl-4 pb-4 mb-4 last:pb-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-300">{mov.date} - {mov.time}</span>
                  <span className="px-2 py-1 bg-blue-500/20 text-blue-300 rounded text-xs">{mov.type}</span>
                </div>
                <p className="text-sm text-white">{mov.description}</p>
              </div>
            ))}
          </TabsContent>
          
          <TabsContent value="documents" className="mt-4 max-h-[60vh] overflow-y-auto">
            {process.documents.map((doc, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-white/5 rounded border border-white/10 mb-2">
                <div>
                  <p className="text-sm text-white font-medium">{doc.name}</p>
                  <p className="text-xs text-gray-400">{doc.date}</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button size="sm" variant="ghost" onClick={() => handleOpenPdf(doc.url)}><ExternalLink className="w-4 h-4 text-blue-300" /></Button>
                  <Button size="sm" variant="ghost" onClick={() => toast({ title: "🚧 Funcionalidade em Desenvolvimento", description: "O upload de novos documentos estará disponível em breve! 🚀" })}><Plus className="w-4 h-4 text-green-300" /></Button>
                </div>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="notes" className="mt-4 space-y-4">
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Adicione suas anotações sobre o processo aqui..."
              className="bg-slate-800 border-slate-600 h-64"
            />
            <Button onClick={handleSaveNotes}>Salvar Anotações</Button>
          </TabsContent>
          
          <TabsContent value="commitments" className="mt-4 space-y-4">
            <div className="flex space-x-2">
              <Input type="date" value={newCommitment.date} onChange={(e) => setNewCommitment({...newCommitment, date: e.target.value})} className="bg-slate-800 border-slate-600" />
              <Input placeholder="Descrição do prazo/audiência" value={newCommitment.description} onChange={(e) => setNewCommitment({...newCommitment, description: e.target.value})} className="bg-slate-800 border-slate-600" />
              <Button onClick={handleAddCommitment}><Plus className="w-4 h-4" /></Button>
            </div>
            <div className="space-y-2 max-h-[45vh] overflow-y-auto">
              {commitments.map(c => (
                <div key={c.id} className="flex justify-between items-center p-2 bg-white/5 rounded">
                  <div>
                    <p className="font-bold">{new Date(c.date + 'T00:00:00').toLocaleDateString('pt-BR')}</p>
                    <p>{c.description}</p>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => handleDeleteCommitment(c.id)}><Trash2 className="w-4 h-4 text-red-400" /></Button>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="actions" className="mt-4 grid grid-cols-2 gap-4">
             <Button variant="outline" className="h-20" onClick={() => toast({ title: "🚧 Funcionalidade em Desenvolvimento"})}>
                <Link className="w-5 h-5 mr-2"/> Relacionar Processo
             </Button>
             <Button variant="outline" className="h-20" onClick={() => toast({ title: "🚧 Funcionalidade em Desenvolvimento"})}>
                <Share2 className="w-5 h-5 mr-2"/> Compartilhar Visualização
             </Button>
          </TabsContent>

        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default ProcessDetailModal;
