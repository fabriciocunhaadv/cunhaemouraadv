
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, FileText, Bell, Users, TrendingUp, Eye, Plus, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import ProcessSearch from '@/components/ProcessSearch';
import ProcessList from '@/components/ProcessList';
import PublicationMonitor from '@/components/PublicationMonitor';
import StatsCards from '@/components/StatsCards';
import { tribunals as allTribunals } from '@/utils/processData';

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [processes, setProcesses] = useState([]);
  const [publications, setPublications] = useState([]);

  useEffect(() => {
    const savedProcesses = localStorage.getItem('processual_processes');
    const savedPublications = localStorage.getItem('processual_publications');
    
    if (savedProcesses) setProcesses(JSON.parse(savedProcesses));
    if (savedPublications) setPublications(JSON.parse(savedPublications));
  }, []);

  const addProcess = (processData) => {
    const isDuplicate = processes.some(p => p.number === processData.number);
    if (isDuplicate) {
      toast({ title: "Processo já monitorado", description: "Este processo já está na sua lista.", variant: "destructive" });
      return;
    }
    
    const tribunalInfo = allTribunals.find(t => t.code === processData.tribunalCode);
    const newProcess = {
      id: Date.now(),
      court: tribunalInfo?.name || processData.court,
      ...processData,
      createdAt: new Date().toISOString(),
      status: processData.status || 'Ativo',
      lastUpdate: processData.lastUpdate || new Date().toISOString()
    };
    
    const updatedProcesses = [...processes, newProcess];
    setProcesses(updatedProcesses);
    localStorage.setItem('processual_processes', JSON.stringify(updatedProcesses));
    
    toast({
      title: "Processo Adicionado!",
      description: `Processo ${processData.number} foi adicionado ao monitoramento.`,
    });
  };

  const addMultipleProcesses = (processList) => {
    processList.forEach(proc => addProcess(proc));
  };


  const addPublication = (publicationData) => {
    const newPublication = { id: Date.now(), ...publicationData, createdAt: new Date().toISOString(), read: false };
    const updatedPublications = [...publications, newPublication];
    setPublications(updatedPublications);
    localStorage.setItem('processual_publications', JSON.stringify(updatedPublications));
  };

  const handleExportAllData = () => {
    const exportData = {
      module: 'processual_perfexcrm',
      version: '1.1',
      export_date: new Date().toISOString(),
      summary: {
        total_processes: processes.length,
        total_publications: publications.length,
      },
      processes: processes,
      publications: publications,
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `modulo_processual_perfexcrm_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({ title: "Dados Exportados!", description: "Todos os dados foram exportados para importação no PerfexCRM." });
  };

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: TrendingUp },
    { id: 'search', label: 'Consulta Processual', icon: Search },
    { id: 'processes', label: 'Processos', icon: FileText },
    { id: 'publications', label: 'Advogados', icon: Users }
  ];

  return (
    <div className="min-h-screen">
      <header className="bg-white/10 backdrop-blur-lg border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Módulo Processual</h1>
                <p className="text-blue-200">Consulta e Monitoramento Jurídico</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button onClick={handleExportAllData} variant="outline" size="sm" className="border-green-500 text-green-400 hover:bg-green-500/10"><Download className="w-4 h-4 mr-2" />Exportar Tudo</Button>
            </div>
          </div>
        </div>
        <nav className="bg-white/5 backdrop-blur-sm border-t border-b border-white/10">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex space-x-8">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center space-x-2 py-3 px-1 border-b-2 transition-colors ${activeTab === tab.id ? 'border-blue-400 text-blue-300' : 'border-transparent text-gray-300 hover:text-white'}`}>
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </nav>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === 'dashboard' && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
            <div className="flex items-center justify-between"><h2 className="text-3xl font-bold text-white">Dashboard</h2><Button onClick={() => setActiveTab('search')} className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"><Plus className="w-4 h-4 mr-2" />Nova Consulta</Button></div>
            <StatsCards processes={processes} publications={publications} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }} className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-6"><div className="flex items-center justify-between mb-6"><h3 className="text-xl font-semibold text-white">Processos Recentes</h3><Button variant="ghost" size="sm" onClick={() => setActiveTab('processes')} className="text-blue-300 hover:text-white"><Eye className="w-4 h-4 mr-2" />Ver Todos</Button></div><div className="space-y-4">{processes.slice(-3).reverse().map((process) => (<div key={process.id} className="bg-white/5 rounded-lg p-4 border border-white/10"><div className="flex items-center justify-between"><div><p className="font-medium text-white">{process.number}</p><p className="text-sm text-gray-300">{process.court}</p></div><span className="px-3 py-1 bg-green-500/20 text-green-300 rounded-full text-sm">{process.status}</span></div></div>))}{processes.length === 0 && (<div className="text-center py-8 text-gray-400"><FileText className="w-12 h-12 mx-auto mb-4 opacity-50" /><p>Nenhum processo monitorado ainda</p></div>)}</div></motion.div>
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }} className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-6"><div className="flex items-center justify-between mb-6"><h3 className="text-xl font-semibold text-white">Publicações Recentes</h3><Button variant="ghost" size="sm" onClick={() => setActiveTab('publications')} className="text-blue-300 hover:text-white"><Eye className="w-4 h-4 mr-2" />Ver Todas</Button></div><div className="space-y-4">{publications.slice(-3).reverse().map((publication) => (<div key={publication.id} className="bg-white/5 rounded-lg p-4 border border-white/10"><div className="flex items-start justify-between"><div className="flex-1"><p className="font-medium text-white">{publication.title}</p><p className="text-sm text-gray-300 mt-1">{publication.lawyer}</p><p className="text-xs text-gray-400 mt-2">{publication.date}</p></div>{!publication.read && (<span className="w-3 h-3 bg-blue-500 rounded-full"></span>)}</div></div>))}{publications.length === 0 && (<div className="text-center py-8 text-gray-400"><Bell className="w-12 h-12 mx-auto mb-4 opacity-50" /><p>Nenhuma publicação encontrada</p></div>)}</div></motion.div>
            </div>
          </motion.div>
        )}
        {activeTab === 'search' && <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}><ProcessSearch onAddProcess={addProcess} /></motion.div>}
        {activeTab === 'processes' && <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}><ProcessList processes={processes} setProcesses={setProcesses} /></motion.div>}
        {activeTab === 'publications' && <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}><PublicationMonitor publications={publications} setPublications={setPublications} onAddPublication={addPublication} onAddMultipleProcesses={addMultipleProcesses} /></motion.div>}
      </main>
    </div>
  );
};

export default Dashboard;
