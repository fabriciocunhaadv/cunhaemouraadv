import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User, MapPin, Hash, Plus, X, Mail, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';

const LawyerMonitoringForm = ({ onClose, onAddLawyer }) => {
  const [lawyerData, setLawyerData] = useState({
    name: '',
    oabNumber: '',
    oabState: '',
    email: '',
    phone: ''
  });

  const brazilianStates = [
    { code: 'AC', name: 'Acre' },
    { code: 'AL', name: 'Alagoas' },
    { code: 'AP', name: 'Amapá' },
    { code: 'AM', name: 'Amazonas' },
    { code: 'BA', name: 'Bahia' },
    { code: 'CE', name: 'Ceará' },
    { code: 'DF', name: 'Distrito Federal' },
    { code: 'ES', name: 'Espírito Santo' },
    { code: 'GO', name: 'Goiás' },
    { code: 'MA', name: 'Maranhão' },
    { code: 'MT', name: 'Mato Grosso' },
    { code: 'MS', name: 'Mato Grosso do Sul' },
    { code: 'MG', name: 'Minas Gerais' },
    { code: 'PA', name: 'Pará' },
    { code: 'PB', name: 'Paraíba' },
    { code: 'PR', name: 'Paraná' },
    { code: 'PE', name: 'Pernambuco' },
    { code: 'PI', name: 'Piauí' },
    { code: 'RJ', name: 'Rio de Janeiro' },
    { code: 'RN', name: 'Rio Grande do Norte' },
    { code: 'RS', name: 'Rio Grande do Sul' },
    { code: 'RO', name: 'Rondônia' },
    { code: 'RR', name: 'Roraima' },
    { code: 'SC', name: 'Santa Catarina' },
    { code: 'SP', name: 'São Paulo' },
    { code: 'SE', name: 'Sergipe' },
    { code: 'TO', name: 'Tocantins' }
  ];

  const handleSubmit = () => {
    if (!lawyerData.name.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, informe o nome do advogado.",
        variant: "destructive"
      });
      return;
    }

    if (!lawyerData.oabNumber.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, informe o número da OAB.",
        variant: "destructive"
      });
      return;
    }

    if (!lawyerData.oabState) {
      toast({
        title: "Erro",
        description: "Por favor, selecione o estado da OAB.",
        variant: "destructive"
      });
      return;
    }

    const lawyerInfo = {
      ...lawyerData,
      oab: `OAB/${lawyerData.oabState} ${lawyerData.oabNumber}`,
      createdAt: new Date().toISOString(),
      monitoring: true
    };

    onAddLawyer(lawyerInfo);
    
    setLawyerData({
      name: '',
      oabNumber: '',
      oabState: '',
      email: '',
      phone: ''
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-8"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <User className="w-6 h-6 text-blue-400" />
          <h3 className="text-xl font-semibold text-white">Monitorar Advogado</h3>
        </div>
        <Button
          onClick={onClose}
          variant="ghost"
          size="sm"
          className="text-gray-400 hover:text-white"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Nome Completo do Advogado *
          </label>
          <Input
            placeholder="Ex: Dr. João Silva Santos"
            value={lawyerData.name}
            onChange={(e) => setLawyerData({...lawyerData, name: e.target.value})}
            className="bg-white/10 border-white/20 text-white placeholder-gray-400"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Número da OAB *
          </label>
          <div className="relative">
            <Hash className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="123456"
              value={lawyerData.oabNumber}
              onChange={(e) => setLawyerData({...lawyerData, oabNumber: e.target.value})}
              className="pl-10 bg-white/10 border-white/20 text-white placeholder-gray-400"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Estado da OAB *
          </label>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 z-10" />
            <Select
              value={lawyerData.oabState}
              onValueChange={(value) => setLawyerData({...lawyerData, oabState: value})}
              placeholder="Selecione o estado"
              className="pl-10 bg-white/10 border-white/20 text-white"
            >
              {brazilianStates.map((state) => (
                <option key={state.code} value={state.code}>
                  {state.code} - {state.name}
                </option>
              ))}
            </Select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            E-mail (Opcional)
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              type="email"
              placeholder="advogado@email.com"
              value={lawyerData.email}
              onChange={(e) => setLawyerData({...lawyerData, email: e.target.value})}
              className="pl-10 bg-white/10 border-white/20 text-white placeholder-gray-400"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Telefone (Opcional)
          </label>
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="(11) 99999-9999"
              value={lawyerData.phone}
              onChange={(e) => setLawyerData({...lawyerData, phone: e.target.value})}
              className="pl-10 bg-white/10 border-white/20 text-white placeholder-gray-400"
            />
          </div>
        </div>
      </div>

      <div className="mt-8 flex space-x-4">
        <Button
          onClick={handleSubmit}
          className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 flex-1"
        >
          <Plus className="w-4 h-4 mr-2" />
          Adicionar ao Monitoramento
        </Button>
        <Button
          onClick={onClose}
          variant="outline"
          className="border-white/20 text-white hover:bg-white/10"
        >
          Cancelar
        </Button>
      </div>

      <div className="mt-6 p-4 bg-blue-500/10 rounded-lg border border-blue-500/20">
        <h4 className="text-sm font-medium text-blue-300 mb-2">ℹ️ Como funciona o monitoramento:</h4>
        <ul className="text-xs text-gray-300 space-y-1">
          <li>• Busca automática diária nos diários oficiais</li>
          <li>• Notificações em tempo real de novas publicações</li>
          <li>• Histórico completo de publicações encontradas</li>
          <li>• Exportação de dados para PerfexCRM</li>
        </ul>
      </div>
    </motion.div>
  );
};

export default LawyerMonitoringForm;