
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bell, Search, Filter, Eye, Plus, Calendar, User, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import LawyerMonitoringForm from '@/components/LawyerMonitoringForm';
import LawyerList from '@/components/LawyerList';

const PublicationMonitor = ({ publications, setPublications, onAddPublication, onAddMultipleProcesses }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRead, setFilterRead] = useState('all');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showLawyerList, setShowLawyerList] = useState(false);
  const [monitoredLawyers, setMonitoredLawyers] = useState([]);

  useEffect(() => {
    const savedLawyers = localStorage.getItem('monitored_lawyers');
    if (savedLawyers) {
      setMonitoredLawyers(JSON.parse(savedLawyers));
    }
  }, []);

  const filteredPublications = publications.filter(publication => {
    const matchesSearch = publication.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         publication.lawyer.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = filterRead === 'all' || 
                         (filterRead === 'read' && publication.read) ||
                         (filterRead === 'unread' && !publication.read);
    
    return matchesSearch && matchesFilter;
  });

  const handleMarkAsRead = (publicationId) => {
    const updatedPublications = publications.map(pub =>
      pub.id === publicationId ? { ...pub, read: true } : pub
    );
    setPublications(updatedPublications);
    localStorage.setItem('processual_publications', JSON.stringify(updatedPublications));
    
    toast({
      title: "Marcado como Lido",
      description: "A publicação foi marcada como lida.",
    });
  };

  const handleAddLawyer = (lawyerData) => {
    const newLawyer = { id: Date.now(), ...lawyerData };
    const updatedLawyers = [...monitoredLawyers, newLawyer];
    setMonitoredLawyers(updatedLawyers);
    localStorage.setItem('monitored_lawyers', JSON.stringify(updatedLawyers));
    
    toast({
      title: "Advogado Adicionado!",
      description: `${lawyerData.name} foi adicionado ao monitoramento.`,
    });
    setShowAddForm(false);
    
    // Simulate finding processes for the new lawyer
    if (lawyerData.oab.includes('48353')) {
      const mockProcesses = [
        {
          number: '0000081-88.2025.5.18.0181',
          tribunalCode: 'TRT18',
          subject: 'Reconhecimento de Vínculo Empregatício',
          class: 'Ação Trabalhista - Rito Ordinário',
          parties: { plaintiff: 'Maria Joaquina de Amaral Pereira', defendant: 'Tecnologia Avançada Ltda.' },
          lawyers: [{ name: 'Fabricio Alves da Cunha', oab: 'OAB/GO 48353', party: 'Polo Passivo' }],
          distribuition: '01/01/2025'
        }
      ];
      onAddMultipleProcesses(mockProcesses);
      toast({
        title: "Processos Encontrados!",
        description: `Encontramos ${mockProcesses.length} processos para ${lawyerData.name}.`,
      });
    }
  };


  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-white">Publicações e Advogados</h2>
        <div className="flex space-x-4">
          <Button onClick={() => setShowLawyerList(!showLawyerList)} variant="outline" className="border-blue-500 text-blue-400 hover:bg-blue-500/10"><User className="w-4 h-4 mr-2" />Gerenciar Advogados ({monitoredLawyers.length})</Button>
          <Button onClick={() => setShowAddForm(!showAddForm)} variant="outline" className="border-white/20 text-white hover:bg-white/10"><Plus className="w-4 h-4 mr-2" />Monitorar Advogado</Button>
        </div>
      </div>

      {showLawyerList && <LawyerList lawyers={monitoredLawyers} setLawyers={setMonitoredLawyers} onClose={() => setShowLawyerList(false)} />}
      {showAddForm && <LawyerMonitoringForm onClose={() => setShowAddForm(false)} onAddLawyer={handleAddLawyer} />}

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input placeholder="Buscar publicações..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10 bg-white/10 border-white/20 text-white placeholder-gray-400" />
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Filter className="w-5 h-5 text-gray-400" />
              <Select value={filterRead} onValueChange={setFilterRead} className="bg-slate-800 border-slate-600">
                <option value="all">Todas</option>
                <option value="unread">Não Lidas</option>
                <option value="read">Lidas</option>
              </Select>
            </div>
            <div className="text-sm text-gray-300">{filteredPublications.length} publicações</div>
          </div>
        </div>
      </motion.div>

      <div className="space-y-4">
        {filteredPublications.length > 0 ? (
          filteredPublications.map((publication, index) => (
            <motion.div key={publication.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }} className={`bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-6 hover:bg-white/15 transition-all duration-300 ${!publication.read ? 'border-l-4 border-l-blue-500' : ''}`}>
              <div className="flex items-start justify-between">
                <div className="flex-1 space-y-4">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-600 rounded-lg flex items-center justify-center"><Bell className="w-6 h-6 text-white" /></div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-semibold text-white">{publication.title}</h3>
                        {!publication.read && (<span className="w-3 h-3 bg-blue-500 rounded-full"></span>)}
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div className="flex items-center space-x-2"><User className="w-4 h-4 text-orange-400" /><div><p className="text-xs text-gray-400">Advogado</p><p className="text-sm text-white">{publication.lawyer}</p>{publication.oab && (<p className="text-xs text-gray-400">{publication.oab}</p>)}</div></div>
                        <div className="flex items-center space-x-2"><Calendar className="w-4 h-4 text-orange-400" /><div><p className="text-xs text-gray-400">Data</p><p className="text-sm text-white">{publication.date}</p></div></div>
                        <div className="flex items-center space-x-2"><FileText className="w-4 h-4 text-orange-400" /><div><p className="text-xs text-gray-400">Fonte</p><p className="text-sm text-white">{publication.source}</p></div></div>
                      </div>
                      {publication.content && (<div className="bg-white/5 rounded-lg p-4 border border-white/10"><p className="text-sm text-gray-300 line-clamp-3">{publication.content}</p></div>)}
                    </div>
                  </div>
                </div>
                <div className="flex flex-col space-y-2 ml-6">
                  <Button variant="ghost" size="sm" onClick={() => toast({title: "🚧 Funcionalidade em Desenvolvimento"})} className="text-blue-300 hover:text-white hover:bg-blue-500/20"><Eye className="w-4 h-4" /></Button>
                  {!publication.read && (<Button variant="ghost" size="sm" onClick={() => handleMarkAsRead(publication.id)} className="text-green-300 hover:text-white hover:bg-green-500/20">✓</Button>)}
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-12 text-center">
            <Bell className="w-16 h-16 text-gray-400 mx-auto mb-4" /><h3 className="text-xl font-semibold text-white mb-2">{searchTerm || filterRead !== 'all' ? 'Nenhuma publicação encontrada' : 'Nenhuma publicação monitorada'}</h3><p className="text-gray-400 mb-6">{searchTerm || filterRead !== 'all' ? 'Tente ajustar os filtros de busca' : 'Comece adicionando advogados para monitoramento'}</p>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default PublicationMonitor;
