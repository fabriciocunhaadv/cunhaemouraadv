import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Edit, Trash2, X, Search, MapPin, Hash, Mail, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';

const LawyerList = ({ lawyers, setLawyers, onClose }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [editingLawyer, setEditingLawyer] = useState(null);
  const [editData, setEditData] = useState({});

  const brazilianStates = [
    { code: 'AC', name: 'Acre' },
    { code: 'AL', name: 'Alagoas' },
    { code: 'AP', name: 'Amapá' },
    { code: 'AM', name: 'Amazonas' },
    { code: 'BA', name: 'Bahia' },
    { code: 'CE', name: 'Ceará' },
    { code: 'DF', name: 'Distrito Federal' },
    { code: 'ES', name: 'Espírito Santo' },
    { code: 'GO', name: 'Goiás' },
    { code: 'MA', name: 'Maranhão' },
    { code: 'MT', name: 'Mato Grosso' },
    { code: 'MS', name: 'Mato Grosso do Sul' },
    { code: 'MG', name: 'Minas Gerais' },
    { code: 'PA', name: 'Pará' },
    { code: 'PB', name: 'Paraíba' },
    { code: 'PR', name: 'Paraná' },
    { code: 'PE', name: 'Pernambuco' },
    { code: 'PI', name: 'Piauí' },
    { code: 'RJ', name: 'Rio de Janeiro' },
    { code: 'RN', name: 'Rio Grande do Norte' },
    { code: 'RS', name: 'Rio Grande do Sul' },
    { code: 'RO', name: 'Rondônia' },
    { code: 'RR', name: 'Roraima' },
    { code: 'SC', name: 'Santa Catarina' },
    { code: 'SP', name: 'São Paulo' },
    { code: 'SE', name: 'Sergipe' },
    { code: 'TO', name: 'Tocantins' }
  ];

  const filteredLawyers = lawyers.filter(lawyer =>
    lawyer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lawyer.oab.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleEdit = (lawyer) => {
    setEditingLawyer(lawyer.id);
    setEditData({
      name: lawyer.name,
      oabNumber: lawyer.oabNumber,
      oabState: lawyer.oabState,
      email: lawyer.email || '',
      phone: lawyer.phone || ''
    });
  };

  const handleSaveEdit = () => {
    if (!editData.name.trim() || !editData.oabNumber.trim() || !editData.oabState) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }

    const updatedLawyers = lawyers.map(lawyer =>
      lawyer.id === editingLawyer
        ? {
            ...lawyer,
            ...editData,
            oab: `OAB/${editData.oabState} ${editData.oabNumber}`,
            updatedAt: new Date().toISOString()
          }
        : lawyer
    );

    setLawyers(updatedLawyers);
    localStorage.setItem('monitored_lawyers', JSON.stringify(updatedLawyers));
    setEditingLawyer(null);
    setEditData({});

    toast({
      title: "Advogado Atualizado!",
      description: "Os dados do advogado foram atualizados com sucesso.",
    });
  };

  const handleDelete = (lawyerId) => {
    const updatedLawyers = lawyers.filter(lawyer => lawyer.id !== lawyerId);
    setLawyers(updatedLawyers);
    localStorage.setItem('monitored_lawyers', JSON.stringify(updatedLawyers));

    toast({
      title: "Advogado Removido",
      description: "O advogado foi removido do monitoramento.",
    });
  };

  const handleCancelEdit = () => {
    setEditingLawyer(null);
    setEditData({});
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-8"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <User className="w-6 h-6 text-blue-400" />
          <h3 className="text-xl font-semibold text-white">Advogados Monitorados</h3>
          <span className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm">
            {lawyers.length} advogados
          </span>
        </div>
        <Button
          onClick={onClose}
          variant="ghost"
          size="sm"
          className="text-gray-400 hover:text-white"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input
            placeholder="Buscar por nome ou OAB..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-white/10 border-white/20 text-white placeholder-gray-400"
          />
        </div>
      </div>

      <div className="space-y-4 max-h-96 overflow-y-auto">
        {filteredLawyers.length > 0 ? (
          filteredLawyers.map((lawyer) => (
            <div key={lawyer.id} className="bg-white/5 rounded-lg p-4 border border-white/10">
              {editingLawyer === lawyer.id ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs text-gray-400 mb-1">Nome Completo *</label>
                      <Input
                        value={editData.name}
                        onChange={(e) => setEditData({...editData, name: e.target.value})}
                        className="bg-white/10 border-white/20 text-white text-sm"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs text-gray-400 mb-1">Número da OAB *</label>
                      <div className="relative">
                        <Hash className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <Input
                          value={editData.oabNumber}
                          onChange={(e) => setEditData({...editData, oabNumber: e.target.value})}
                          className="pl-10 bg-white/10 border-white/20 text-white text-sm"
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-xs text-gray-400 mb-1">Estado da OAB *</label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 z-10" />
                        <Select
                          value={editData.oabState}
                          onValueChange={(value) => setEditData({...editData, oabState: value})}
                          className="pl-10 bg-white/10 border-white/20 text-white text-sm"
                        >
                          {brazilianStates.map((state) => (
                            <option key={state.code} value={state.code}>
                              {state.code} - {state.name}
                            </option>
                          ))}
                        </Select>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-xs text-gray-400 mb-1">E-mail</label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <Input
                          type="email"
                          value={editData.email}
                          onChange={(e) => setEditData({...editData, email: e.target.value})}
                          className="pl-10 bg-white/10 border-white/20 text-white text-sm"
                        />
                      </div>
                    </div>
                    
                    <div className="md:col-span-2">
                      <label className="block text-xs text-gray-400 mb-1">Telefone</label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <Input
                          value={editData.phone}
                          onChange={(e) => setEditData({...editData, phone: e.target.value})}
                          className="pl-10 bg-white/10 border-white/20 text-white text-sm"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-3">
                    <Button
                      onClick={handleSaveEdit}
                      size="sm"
                      className="bg-green-600 hover:bg-green-700"
                    >
                      Salvar
                    </Button>
                    <Button
                      onClick={handleCancelEdit}
                      variant="outline"
                      size="sm"
                      className="border-white/20 text-white hover:bg-white/10"
                    >
                      Cancelar
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                        <User className="w-5 h-5 text-white" />
                      </div>
                      
                      <div className="flex-1">
                        <h4 className="text-white font-medium">{lawyer.name}</h4>
                        <p className="text-sm text-gray-300">{lawyer.oab}</p>
                        
                        <div className="flex items-center space-x-4 mt-2">
                          {lawyer.email && (
                            <div className="flex items-center space-x-1">
                              <Mail className="w-3 h-3 text-gray-400" />
                              <span className="text-xs text-gray-400">{lawyer.email}</span>
                            </div>
                          )}
                          {lawyer.phone && (
                            <div className="flex items-center space-x-1">
                              <Phone className="w-3 h-3 text-gray-400" />
                              <span className="text-xs text-gray-400">{lawyer.phone}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button
                      onClick={() => handleEdit(lawyer)}
                      variant="ghost"
                      size="sm"
                      className="text-blue-300 hover:text-white hover:bg-blue-500/20"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    
                    <Button
                      onClick={() => handleDelete(lawyer.id)}
                      variant="ghost"
                      size="sm"
                      className="text-red-300 hover:text-white hover:bg-red-500/20"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-gray-400">
            <User className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>
              {searchTerm ? 'Nenhum advogado encontrado' : 'Nenhum advogado monitorado ainda'}
            </p>
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default LawyerList;