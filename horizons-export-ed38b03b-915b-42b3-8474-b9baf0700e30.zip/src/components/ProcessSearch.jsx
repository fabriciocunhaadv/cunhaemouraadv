
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Download, Globe, Scale, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/components/ui/use-toast';
import ProcessSearchForm from '@/components/ProcessSearchForm';
import ProcessResults from '@/components/ProcessResults';
import { searchProcessInTribunals } from '@/utils/processSearch';

const ProcessSearch = ({ onAddProcess }) => {
  const [processNumber, setProcessNumber] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState(null);
  const [searchProgress, setSearchProgress] = useState([]);

  const handleAutoSearch = async () => {
    if (!processNumber.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, informe o número do processo.",
        variant: "destructive"
      });
      return;
    }

    setIsSearching(true);
    setSearchProgress([]);
    setSearchResults(null);

    try {
      const result = await searchProcessInTribunals(processNumber, setSearchProgress);
      setSearchResults(result);
      
      toast({
        title: "Busca Concluída!",
        description: `Processo encontrado no ${result.courtCode}.`,
      });
    } catch (error) {
      toast({
        title: "Processo não encontrado",
        description: "Não foi possível localizar o processo nos tribunais consultados.",
        variant: "destructive"
      });
    } finally {
      setIsSearching(false);
    }
  };

  const handleAddToMonitoring = () => {
    if (searchResults) {
      onAddProcess(searchResults);
      setSearchResults(null);
      setProcessNumber('');
    }
  };

  const handleExportToPerfex = () => {
    if (!searchResults) return;

    const perfexData = {
      module: 'processual',
      version: '1.0',
      export_date: new Date().toISOString(),
      process: {
        number: searchResults.number,
        court: searchResults.court,
        court_code: searchResults.courtCode,
        status: searchResults.status,
        subject: searchResults.subject,
        class: searchResults.class,
        value: searchResults.value,
        judge: searchResults.judge,
        vara: searchResults.vara,
        comarca: searchResults.comarca,
        distribution_date: searchResults.distribuition,
        last_update: searchResults.lastUpdate,
        parties: {
          plaintiff: {
            name: searchResults.parties.plaintiff,
            document: searchResults.parties.plaintiffCpf,
            type: 'person'
          },
          defendant: {
            name: searchResults.parties.defendant,
            document: searchResults.parties.defendantCnpj,
            type: 'company'
          }
        },
        lawyer: {
          name: searchResults.lawyer,
          oab: searchResults.oab
        },
        movements: searchResults.movements.map(mov => ({
          date: mov.date,
          time: mov.time,
          description: mov.description,
          type: mov.type,
          responsible: mov.responsible
        })),
        documents: searchResults.documents,
        monitoring: {
          active: true,
          created_at: new Date().toISOString(),
          notifications: true
        }
      }
    };

    const blob = new Blob([JSON.stringify(perfexData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `processo_${searchResults.number.replace(/[^0-9]/g, '')}_perfexcrm.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Arquivo Exportado!",
      description: "Dados do processo exportados para importação no PerfexCRM.",
    });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white">Consulta Processual Automática</h2>
          <p className="text-gray-300 mt-2">Busca automática em todos os tribunais do Brasil</p>
        </div>
        <div className="flex items-center space-x-2 text-sm text-gray-400">
          <Globe className="w-4 h-4" />
          <span>21 tribunais conectados</span>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-8"
      >
        <div className="flex items-center space-x-3 mb-6">
          <Zap className="w-6 h-6 text-yellow-400" />
          <h3 className="text-xl font-semibold text-white">Busca Inteligente</h3>
          <span className="px-3 py-1 bg-yellow-500/20 text-yellow-300 rounded-full text-sm">
            Automática
          </span>
        </div>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Número do Processo *
            </label>
            <div className="flex space-x-4">
              <Input
                placeholder="Ex: 1234567-89.2024.8.26.0001"
                value={processNumber}
                onChange={(e) => setProcessNumber(e.target.value)}
                className="flex-1 bg-white/10 border-white/20 text-white placeholder-gray-400"
              />
              <Button
                onClick={handleAutoSearch}
                disabled={isSearching}
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 min-w-[200px]"
              >
                {isSearching ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Consultando...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    Buscar Automaticamente
                  </>
                )}
              </Button>
            </div>
          </div>

          {isSearching && searchProgress.length > 0 && (
            <div className="bg-white/5 rounded-lg p-4 border border-white/10">
              <h4 className="text-sm font-medium text-white mb-3">Progresso da Busca:</h4>
              <div className="space-y-2">
                {searchProgress.map((progress, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${
                      progress.status === 'searching' ? 'bg-yellow-400 animate-pulse' :
                      progress.status === 'found' ? 'bg-green-400' :
                      progress.status === 'not_found' ? 'bg-gray-400' : 'bg-red-400'
                    }`}></div>
                    <span className="text-sm text-gray-300">{progress.tribunal}</span>
                    <span className={`text-xs px-2 py-1 rounded ${
                      progress.status === 'searching' ? 'bg-yellow-500/20 text-yellow-300' :
                      progress.status === 'found' ? 'bg-green-500/20 text-green-300' :
                      progress.status === 'not_found' ? 'bg-gray-500/20 text-gray-300' : 'bg-red-500/20 text-red-300'
                    }`}>
                      {progress.status === 'searching' ? 'Consultando...' :
                       progress.status === 'found' ? 'Encontrado!' :
                       progress.status === 'not_found' ? 'Não encontrado' : 'Erro'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {searchResults && (
            <div className="flex space-x-4">
              <Button
                onClick={handleExportToPerfex}
                variant="outline"
                className="border-green-500 text-green-400 hover:bg-green-500/10"
              >
                <Download className="w-4 h-4 mr-2" />
                Exportar para PerfexCRM
              </Button>
            </div>
          )}
        </div>
      </motion.div>

      {searchResults && (
        <ProcessResults 
          searchResults={searchResults}
          onAddToMonitoring={handleAddToMonitoring}
          onExportToPerfex={handleExportToPerfex}
        />
      )}

      <ProcessSearchForm onAddProcess={onAddProcess} />
    </div>
  );
};

export default ProcessSearch;
